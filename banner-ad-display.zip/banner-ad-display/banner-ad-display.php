<?php
/*
Plugin Name: Banner Ad Display
Plugin URI: http://www.InternetMarketingScout.com
Description: Add 3 affiliate banners or Text boxes to the bottom of your download page with the click of a button!
Version: 1.0
Author: Duncan - Internet Marketing Scout
Author URI: http://www.internetmarketingscout.com
*/
define( 'PLUGIN_PATH', plugin_dir_path( __FILE__ ) );




function create_profit_booster() {
	register_post_type( 'profit_boosters',
		array(
			'labels' => array(
				'name' => 'Banner Ad Display',
				'singular_name' => 'Banner Ad Display',
				'add_new' => 'Add New',
				'add_new_item' => 'Add New Banner Ad Set',
				'edit' => 'Edit',
				'edit_item' => 'Edit Banner Ad Set',
				'new_item' => 'New Banner Ad Set',
				'view' => '',
				'view_item' => '',
				'search_items' => 'Search Banner Ad Sets',
				'not_found' => 'No Banner Ad Sets found',
				'not_found_in_trash' => 'No Banner Ad Sets found in Trash',
				'parent' => 'Parent Banner Ads'
			),

			'public' => true,
			'menu_position' => 15,
			'supports' => array( 'title' ),
			'taxonomies' => array( '' ),
			'capability_type' => 'post',
			'menu_icon' => plugins_url( 'images/icon.png', __FILE__ ),
			'register_meta_box_cb' => 'profit_boosters_meta_boxes', // Callback function for custom metaboxes
			'has_archive' => true
		)
	);
}


add_action('admin_notices', 'pb_admin_notice');
function pb_admin_notice()
{
	global $current_screen;
	global $pagenow, $typenow;
	if (empty($typenow) && !empty($_GET['post'])) {
		$post = get_post($_GET['post']);
		$typenow = $post->post_type;
	}
	if (is_admin() && $typenow=='profit_boosters') {
		echo "<a href='http://internetmarketingscout.com/my/banneradupgrade' id='upgrade_p_b' class='add-new-h2' style='display:none;'>Want More Features? Upgrade To Pro Now! </a>";
	}
}

function posttype_admin_css() {
    global $post_type;
    if($post_type == 'profit_boosters') {
    echo '<style type="text/css">.view{display: none;}.inside #edit-slug-box {display: none;}</style>';
    }
}
add_action('admin_head', 'posttype_admin_css');

add_action( 'init', 'create_profit_booster' );
	
//meta box

function profit_boosters_meta_boxes() {
	add_meta_box( 'profit_boosters_form', 'Set Details', 'profit_boosters_form', 'profit_boosters', 'normal', 'high' );
}

function profit_boosters_form() {
	$post_id = get_the_ID();
	$profit_booster_data = get_post_meta( $post_id, '_profit_booster', true );
	$block_one = ( empty( $profit_booster_data['block_one'] ) ) ? '' : $profit_booster_data['block_one'];
	$block_two = ( empty( $profit_booster_data['block_two'] ) ) ? '' : $profit_booster_data['block_two'];
	$block_three = ( empty( $profit_booster_data['block_three'] ) ) ? '' : $profit_booster_data['block_three'];

	wp_nonce_field( 'profit_boosters', 'profit_boosters' );
	?>
	
	<div style="width:33%;display:inline-block;">
		<label>Banner One - Default Size: 250x250 pixels</label><br />
		<textarea style="width:100%;height:260px;" name="profit_booster[block_one]"><?php echo $block_one; ?></textarea>
	</div>
	<div style="width:33%;display:inline-block;">
		<label>Banner Two - Default Size: 250x250 pixels</label><br />
		<textarea style="width:100%;height:260px;" name="profit_booster[block_two]" ><?php echo $block_two; ?></textarea>
	</div>
	<div style="width:33%;display:inline-block;">
		<label>Banner Three - Default Size: 250x250 pixels</label><br />
		<textarea style="width:100%;height:260px;" name="profit_booster[block_three]"><?php echo $block_three; ?> </textarea>
	</div>
	<?php
}

add_action( 'save_post', 'profit_boosters_save_post' );
function profit_boosters_save_post( $post_id ) {
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE )
		return;

	if ( ! empty( $_POST['profit_boosters'] ) && ! wp_verify_nonce( $_POST['profit_boosters'], 'profit_boosters' ) )
		return;

	if ( ! empty( $_POST['post_type'] ) && 'page' == $_POST['post_type'] ) {
		if ( ! current_user_can( 'edit_page', $post_id ) )
			return;
	} else {
		if ( ! current_user_can( 'edit_post', $post_id ) )
			return;
	}
	
	/*
	if ( ! wp_is_post_revision( $post_id ) && 'profit_boosters' == get_post_type( $post_id ) ) {
		remove_action( 'save_post', 'profit_boosters_save_post' );

		wp_update_post( array(
			'ID' => $post_id,
			'post_title' => 'profit_booster - ' . $post_id
		) );

		add_action( 'save_post', 'profit_boosters_save_post' );
	}
	*/

	if ( ! empty( $_POST['profit_booster'] ) ) {
		$profit_booster_data['block_one'] = ( empty( $_POST['profit_booster']['block_one'] ) ) ? '' : $_POST['profit_booster']['block_one'];
		$profit_booster_data['block_two'] = ( empty( $_POST['profit_booster']['block_two'] ) ) ? '' : $_POST['profit_booster']['block_two'];
		$profit_booster_data['block_three'] = ( empty( $_POST['profit_booster']['block_three'] ) ) ? '' : $_POST['profit_booster']['block_three'];

		update_post_meta( $post_id, '_profit_booster', $profit_booster_data );
	} else {
		delete_post_meta( $post_id, '_profit_booster' );
	}
}


//meta box

// Message Admin
function enqueue_message_js($hook) {
  global $pagenow, $typenow;

  if (empty($typenow) && !empty($_GET['post'])) {
    $post = get_post($_GET['post']);
    $typenow = $post->post_type;
  }
  if (is_admin() && $typenow=='profit_boosters') {
    if ($pagenow!='post-new.php' || $pagenow!='post.php' || $pagenow=='edit.php') { 

    wp_enqueue_script( 'headr_message_script', plugins_url( 'message.js', __FILE__ ),
		array('jquery'));
	}
	}
}
add_action( 'admin_enqueue_scripts', 'enqueue_message_js' );

// Add Upgrade Now Meta Box 
function message_the_admin() {
 $screens = array( 'profit_boosters');

    foreach ( $screens as $screen ) {

        add_meta_box(
            'bap_id',
            __( 'Upgrade To Banner Ad Pro', 'admin_bap_txtdomain' ),
            'message_the_admin_box',
            $screen, 'side', 'high'
        );
    }
}

add_action( 'add_meta_boxes', 'message_the_admin' );

function message_the_admin_box () {

echo "<div style='padding: 10px; text-align: center;'><b>Want More Features? </b><br/><br/><a href='http://internetmarketingscout.com/my/banneradupgrade'><input type='button' class='button-primary button-large button upgr_to_pro' value='Upgrade To Pro Now!'/> </a></div>";

}



/* Display custom column */
function display_posts_shortcode( $column, $post_id ) {
    echo '[profit_booster id='.get_the_ID().']';
}
add_action( 'manage_posts_custom_column' , 'display_posts_shortcode', 10, 2 );

/* Add custom column to post list */
function add_shortcode_column( $columns ) {
    return array_merge( $columns, 
        array( 'Shortcode' => __( 'shortcode', 'your_text_domain' ) ) );
}
add_filter( 'manage_posts_columns' , 'add_shortcode_column' );


//creating the display
function get_profit_booster( $posts_per_page = 1, $orderby = 'none', $id = null ) {
    $args = array(
        'posts_per_page' => (int) $posts_per_page,
        'post_type' => 'profit_boosters',
        'orderby' => $orderby,
        'no_found_rows' => true,
    );
    if ( $id )
        $args['post__in'] = array( $id );
 
    $query = new WP_Query( $args  );
 
    $profit_boosters = '';
    if ( $query->have_posts() ) {
        while ( $query->have_posts() ) : $query->the_post();
            $post_id = get_the_ID();
            $profit_booster_data = get_post_meta( $post_id, '_profit_booster', true );
            $block_one = ( empty( $profit_booster_data['block_one'] ) ) ? '' : $profit_booster_data['block_one'];
            $block_two = ( empty( $profit_booster_data['block_two'] ) ) ? '' : ' - ' . $profit_booster_data['block_two'];
            $block_three = ( empty( $profit_booster_data['block_three'] ) ) ? '' : $profit_booster_data['block_three'];
            
            $cite = '<style>.banner img{width:250px; height: 250px;}</style><center><div style="width:100%"><div class="banner" style="float:left;width:30%;margin-right:5%">'.$block_one.'</div><div class="banner" style="float:left;width:30%;margin-right:5%">'.$block_two.'</div><div class="banner" style="float:left;width:30%;">'.$block_three.'</div></div></center>';
            
            $profit_boosters = $cite;
 
        endwhile;
        wp_reset_postdata();
    }
 
    return $profit_boosters;
}


//adding shortcode to the theme

add_shortcode( 'profit_booster', 'profit_booster_shortcode' );

function profit_booster_shortcode( $atts ) {
    extract( shortcode_atts( array(
        'posts_per_page' => '1',
        'orderby' => 'none',
        'id' => '',
    ), $atts ) );
 
    return get_profit_booster( $posts_per_page, $orderby, $id );
}



//aside shortcode generator

add_action( 'add_meta_boxes', 'profit_boosters_add_custom_box' );


function profit_boosters_add_custom_box(){
	$id = 'profit_booster_shortcode';
	$title = 'Banner Ad';
	$post_types = array( 'post', 'page' );
	$context = 'side';
	$priority = 'high';
	
	foreach ($post_types as $post_type) {
		add_meta_box( $id, $title, 'profit_booster_metabox_callback', $post_type, $context, $priority);
	}
}


function profit_booster_metabox_callback(){
	$profit_boosters = get_profit_boosters();
	echo '<select style="width:100%;" id="tech_profit_boosters" onchange="put_short_code(this)">';
	echo '<option value="">---SELECT---</option>';
	foreach( $profit_boosters as $profit_booster ):?>
		<option value="[profit_booster id=<?php echo $profit_booster->ID; ?>]"><?php echo $profit_booster->post_title; ?></option>
    <?php endforeach;?>
    </select>
    <script>
    
    	 	
    	function put_short_code(sel){
    		//alert("working");
    		var value = sel.options[sel.selectedIndex].value;
    		//insertAtCursor(document.post.content, value);
    		send_to_editor(value);
    		
    	}
		
		
		function insertAtCursor(myField, myValue) {
		
		 //fixed scroll position
		
		 textAreaScrollPosition = myField.scrollTop;
		
		    //IE support
		
		    if (document.selection) {
		
		        myField.focus();
		
		        //in effect we are creating a text range with zero
		
		        //length at the cursor location and replacing it
		
		        //with myValue
		
		        sel = document.selection.createRange();
		
		        sel.text = myValue;
		
		    //Mozilla/Firefox/Netscape 7+ support
		
		    } else if (myField.selectionStart || myField.selectionStart == '0') {
		
		        myField.focus();
		
		        //Here we get the start and end points of the
		
		        //selection. Then we create substrings up to the
		
		        //start of the selection and from the end point
		
		        //of the selection to the end of the field value.
		
		        //Then we concatenate the first substring, myValue,
		
		        //and the second substring to get the new value.
		
		        var startPos = myField.selectionStart;
		
		        var endPos = myField.selectionEnd;
		
		        myField.value = myField.value.substring(0, startPos) + myValue + myField.value.substring(endPos, myField.value.length);
		
		        myField.setSelectionRange(endPos+myValue.length, endPos+myValue.length);
		
		    } else {
		
		        myField.value += myValue;
		
		    }
		
		 //fixed scroll position
		
		 myField.scrollTop = textAreaScrollPosition;
		
		 
		
		}
		
	</script>
	
	
    
<?php    
}



//getting all shortcodes
function get_profit_boosters() {
    $args = array(
	'posts_per_page'  => 999999999,
	'offset'          => 0,
	'category'        => '',
	'orderby'         => 'post_date',
	'order'           => 'DESC',
	'include'         => '',
	'exclude'         => '',
	'meta_key'        => '',
	'meta_value'      => '',
	'post_type'       => 'profit_boosters',
	'post_mime_type'  => '',
	'post_parent'     => '',
	'post_status'     => 'publish',
	'suppress_filters' => true ); 
	
	$posts_array = get_posts( $args );
		 
    return $posts_array;
}

?>