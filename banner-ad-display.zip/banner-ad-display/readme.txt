=== Banner Ad Display ===
Contributors: duncan2222
Donate link: http://www.internetmarketingscout.com/donateplugin/
Tags: banner ads,banners,page,post
Requires at least: 3.7.1
Tested up to: 3.8
Stable tag: 4.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Neatly organize banners or affiliate offers to any page or post.

== Description ==

Organize 3 250x250 banner boxes along with a 977x150 banner section. All neatly stacked on top of one another in a very nice presentation.


== Installation ==


1. Upload `plugin-name.php` to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress
1. Place `<?php do_action('plugin_name_hook'); ?>` in your templates

== Frequently Asked Questions ==

= Do I need to know HTML? =

= For the basic version you will need basic HTML knowledge but not for the upgraded version =

== Screenshots ==
http://internetmarketingscout.com/wpdirectorybanneraddisplayscreenshots/

== Changelog ==

= 1.0 =
* No Changes.

== Upgrade Notice ==

= 1.0 =
Upgrade to the pro version that allows for easy uploads of images and auto resize of images.  No HTML skills required. 


== Arbitrary section ==

None
